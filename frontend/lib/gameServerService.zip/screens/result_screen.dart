/*결과 화면 틀*/

import 'dart:math';
import 'package:flutter/material.dart';
import 'data.dart';

class ResultScreen extends StatelessWidget {
  final String selectedSuspect; // 투표된 용의자

  const ResultScreen({Key? key, required this.selectedSuspect}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final String actualCulprit = GameData.suspects[Random().nextInt(GameData.suspects.length)]; // 실제 범인 랜덤 선택으로 일단 구현
    final bool isCorrect = selectedSuspect == actualCulprit;

    return Scaffold(
      appBar: AppBar(
        title: const Text('결과 화면'),
        backgroundColor: Colors.black,
      ),
      body: Container(
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                '투표 결과:',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                selectedSuspect,
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                '실제 범인:',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                actualCulprit,
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
              const SizedBox(height: 40),
              Text(
                isCorrect ? '범인 찾기 성공!' : '범인 찾기 실패!',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: isCorrect ? Colors.green : Colors.orange,
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                onPressed: () {
                  GameData.resetGameData(); // 게임 데이터 초기화
                  Navigator.pop(context);
                },
                child: const Text(
                  '다시 시작',
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
